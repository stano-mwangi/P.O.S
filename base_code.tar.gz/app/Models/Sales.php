<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sales extends BaseModel
{
    protected $fillable = ['business_id'];
}
