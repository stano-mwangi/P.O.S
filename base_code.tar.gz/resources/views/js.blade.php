<script src="{{asset('/js/bootstrap.bundle.js')}}"></script>
      <!-- bootstrap js -->
      
      <!-- custom js -->
      <script src="/js/custom.js"></script>
    