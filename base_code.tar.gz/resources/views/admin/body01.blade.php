<div class="main-panel">
          <div class="content-wrapper">
          <div class="card">
          <div class="card-body">
            <div class="card-title">
              <p>Welcome {{ Auth::user()->name }}</p>
            </div>
          </div>
        </div>
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>