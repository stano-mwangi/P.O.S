 <!-- Footer -->
 <footer class="modal-footer mt-2">
        <div class="container">
            <p>&copy; 2024 Enterprise Management System. All rights reserved.</p>
        </div>
    </footer>
    </body>
    </html>